#﻿ See INSTALL.txt file to help.

Website= http://thewebmind.org
docs=http://docs.thewebmind.org
contact=contact@thewebmind.org
discussiongroup=http://groups.google.com.br/group/thewebmind
