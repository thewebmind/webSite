<?php
	interface languageInterface
	{
	}
?>