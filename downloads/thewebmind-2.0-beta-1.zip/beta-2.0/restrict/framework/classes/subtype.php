<?php
	class SubType
	{
		
	}
?>