<?php
	include('../../config/mind.php');
	include('../../'.$_MIND['framework']);
	include('../../'.$_MIND['header']);
?>
<iframe src="http://spreadsheets.google.com/embeddedform?key=tXlJv4mhIeTyAXds7qRH7-A" width="570" height="1012" scrolling="no" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>
