<div style='display:none;'>
	<table id='debugerEstructure' style='width:100%;height:100%;'>
		<tr>
			<td style='width:20px;'>
			</td>
			<td>
				<div style='width:100%;
							height: 100%;'
					 id='debugerEstructureTree'>
					<br>
				</div>
				<div style='width:100%;
							height: 100%;'
					 id='debugerEstructureCodes'>
					<center>
						<textarea style='width:49%;height:100%;'></textarea>
						<textarea style='width:49%;height:100%;'></textarea>
					</center>
				</div>
			</td>
		</tr>
	</table>
</div>