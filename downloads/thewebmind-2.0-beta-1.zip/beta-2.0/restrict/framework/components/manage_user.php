<?php
	include('../../config/mind.php');
	include('../../'.$_MIND['framework']);
	include('../../'.$_MIND['header']);
	/*
	$ar= Array();
	$_POST['action']= explode(',', str_replace(' ', '', $_POST['action']));
	if(in_array('list', $_POST['action']))
	{
		$ar['list']= User::getUsers();
	}
	if(in_array('get', $_POST['action']))
	{
		$u= new User($_MIND['fw']->filter($_POST['code']));
		$ar['get']= Array();
		$ar['get']['info']= Array();
		$ar['get']['conf']= Array();
		$ar['get']['info']['name']= $u->name();
		$ar['get']['info']['age']= $u->age();
		$ar['get']['info']['description']= $u->description();
		$ar['get']['info']['position']= $u->position();
		$ar['get']['conf']['login']= $u->login();
		$ar['get']['conf']['status']= $u->status();
		$ar['get']['conf']['email']= $u->email();
	}
	echo json_encode($ar);
	*/
	$u= User::getUsers();
	
?>
<table style="width:100%;height:100%;">
	<tr>
		<td class="user_left_list">
			<div style='overflow:auto;height:470px;overflow-x:hidden;overflow-y:auto;'>
			<table style="width:150px">
			<?php				
				foreach ($u as $a){
					echo "<tr><td userPass='".$a->pwd."' userName='".$a->login."' id='mind_user_manage_".$a->login."' class='list_users'>$a->login</td></tr>";
				}
			?>
			</table>
			</div>
		</td>
		<td class="user_parent"><div class="user_content_list"> </div></td>
	</tr>
	<tr>
		<td colspan="2" id="mind_manage_user_label_message">
		</td>
	<tr>
</table>
<script>
	Mind.View.User.Manage();
</script>
