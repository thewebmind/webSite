<iframe style='width:100%;
			   height:100%;
			   border:none;'
		frameborder='0'
		src="{MIND['home_page']}">
</iframe>