Mind.DataDictionary= function(pObj){
	
}