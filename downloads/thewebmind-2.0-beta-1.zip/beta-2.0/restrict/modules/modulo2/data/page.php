This is only a sample, to show you that any module can load an own file with CSS and JavaScript, to post some extra information it needs.
<table>
	<tr>
		<td>
			Campo 1
		</td>
		<td>
			<input type='text'
				   name='cmp1'
				   id='asd'>
		</td>
	</tr>
	<tr>
		<td>
			Campo 2
		</td>
		<td>
			<input type='text'
				   name='cmp2'
				   class='blabla'>
		</td>
	</tr>
</table>