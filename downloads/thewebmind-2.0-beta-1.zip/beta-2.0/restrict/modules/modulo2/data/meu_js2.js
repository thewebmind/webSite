	$('#asd').live('click', function(){
		alert('aa');
	});