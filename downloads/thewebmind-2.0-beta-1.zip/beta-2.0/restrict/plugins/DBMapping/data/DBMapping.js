Mind.Plugins.DBMapping= {
	/* needed methods */
	Run: function(){
		//this.Save('', '');
	},
	Load: function(){
		
	},
	/***************************/
	Init: function(){
		
	}
}
/*
	os metodos Save, Unlink, MkDir, List e LoadFile ser�o adicionados ao plugin, pelo proprio Mind, sendo assim, s�o palavras reservadas
	Assinaturas:
	
	
	function Save(file_path, content [, flag]):boolean;
	Retorno: true caso funcione, false caso algum erro ocorra
	Parametros:
		file_path: endere�o, incluindo diret�rio para salvar o arquivo, caso nao exista, ser� criado
		content: conte�do a ser salvo no arquivo
		flag: true pra concatenar content ao conteudo do arquivo, false, para substituir todo o conte�do, caso o arquivo j� exista
	
	function Unlink(file_path):boolean;
	Retorno: true caso funcione, false caso algum erro ocorra
	Parametros:
		file_path: endere�o, incluindo diret�rio, do arquivo a ser removido
		
	function MkDir(dir_pach):boolean;
	Retorno: true caso funcione, false caso algum erro ocorra
	Parametros:
		dir_pach: endere�o, incluindo diret�rio pais, de onde o novo diret�rio deve ser criado
		
	function List(dir_pach):ObjectCollection;
	Retorno: ObjectCollection[
									Object[
											name:nome do arquivo ou diret�rio,
											type:directory ou file,
											address:endere�o absoluto do arquivo
										  ]
							 ]
	Parametros:
		dir_pach: endere�o, incluindo diret�rio pais, do diret�rio cujos arquivos ser�o listado
	
	function LoadFile(file_path):Object;
	Retorno: Object[
						name:nome do arquivo,
						address:endere�o completo do arquivo,
						size:tamanho do arquivo,
						content:conte�do do arquivo,
						lastChange:data da ultima modifica��o do arquivo
				   ]
	Parametros:
		file_path: endere�o, incluindo diret�rio, do arquivo a ser carregado
*/