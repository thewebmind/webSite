<div id='Statistics_body'>
	<table>
		<tr>
			<td>
				Tables
			</td>
			<td id='Statistics_tCount'>
				0
			</td>
		</tr>
		<tr>
			<td>
				Attributes
			</td>
			<td id='Statistics_aCount'>
				0 Average: 0
			</td>
		</tr>
		<tr>
			<td>
				Sentences
			</td>
			<td id='Statistics_sCount'>
				0
			</td>
		</tr>
		<tr>
			<td>
				Process time
			</td>
			<td id='Statistics_pTime'>
				0
			</td>
		</tr>
	</table>
</div>
<script>
	Mind.Plugins.Statistics.Build();
</script>
